/**
 * AegisSOC Edge Interceptor v2.6.1 - Main-World Hook (injector.js)
 * 1. WhatsApp Web: Indexes decrypted Blobs lazily in a bounded ring buffer and holds <a download> clicks.
 * 2. Gmail: Hooks window.open(), HTMLAnchorElement.prototype.click, and hidden download iframes so
 *    downloads save directly via verified same-origin Blobs without opening extra browser tabs.
 */
(function () {
  const MAX_BLOB_CACHE = 80;
  const MIN_SCAN_BYTES = 64;
  const MAX_UPLOAD_BYTES = 4 * 1024 * 1024;
  const SLICE_HEADER_BYTES = 256 * 1024;

  const blobRegistry = new Map();
  const approvedBlobUrls = new Set();
  const verifiedUrlBlobs = new Map();

  function isGmailAttachmentUrl(url) {
    if (!url || typeof url !== "string") return false;
    return (
      (url.includes("mail.google.com") &&
        (url.includes("view=att") ||
          url.includes("disp=safe") ||
          url.includes("disp=inline") ||
          url.includes("attid="))) ||
      url.includes("mail-attachment.googleusercontent.com")
    );
  }

  function normalizeAttachmentUrl(rawUrl) {
    try {
      const u = new URL(rawUrl, location.origin);
      u.searchParams.delete("disp");
      u.searchParams.delete("zw");
      u.searchParams.delete("s");
      return u.toString();
    } catch (e) {
      return rawUrl;
    }
  }

  const originalCreateObjectURL = URL.createObjectURL;
  const originalAnchorClick = HTMLAnchorElement.prototype.click;

  function triggerDirectBlobDownload(blob, filename) {
    const cleanName =
      filename && filename.trim() ? filename.trim() : "verified_attachment";
    const objUrl = originalCreateObjectURL.call(URL, blob);
    approvedBlobUrls.add(objUrl);

    const a = document.createElement("a");
    a.href = objUrl;
    a.download = cleanName;
    a.rel = "noopener";
    a.style.display = "none";
    document.body.appendChild(a);
    originalAnchorClick.call(a);

    setTimeout(() => {
      a.remove();
      try {
        URL.revokeObjectURL(objUrl);
      } catch (e) {}
    }, 5000);
  }

  // 1. WHATSAPP WEB: Hook URL.createObjectURL
  URL.createObjectURL = function (obj) {
    const objectUrl = originalCreateObjectURL.apply(this, arguments);
    try {
      if (obj instanceof Blob && obj.size >= MIN_SCAN_BYTES) {
        if (blobRegistry.size >= MAX_BLOB_CACHE) {
          const oldestKey = blobRegistry.keys().next().value;
          blobRegistry.delete(oldestKey);
        }
        blobRegistry.set(objectUrl, {
          blob: obj,
          size: obj.size,
          type: obj.type || "application/octet-stream",
          name: obj.name || null,
          createdAt: Date.now()
        });
      }
    } catch (err) {}
    return objectUrl;
  };

  function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const res = String(reader.result || "");
        const base64 = res.includes(",") ? res.split(",")[1] : res;
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  async function getMagicHex(blob) {
    const slice = blob.slice(0, 8);
    const buf = await slice.arrayBuffer();
    return Array.from(new Uint8Array(buf))
      .map((b) => b.toString(16).padStart(2, "0").toUpperCase())
      .join(" ");
  }

  // 2. HOOK HTMLAnchorElement.prototype.click
  HTMLAnchorElement.prototype.click = function () {
    const href = this.href || "";
    const downloadAttr = this.getAttribute("download");

    if (href.startsWith("blob:") && !approvedBlobUrls.has(href)) {
      const entry = blobRegistry.get(href);
      if (entry && (downloadAttr !== null || entry.size > 256)) {
        const filename = downloadAttr || entry.name || "whatsapp_payload.bin";
        const anchorRef = this;

        (async () => {
          try {
            const magicHex = await getMagicHex(entry.blob);
            const targetBlob =
              entry.blob.size > MAX_UPLOAD_BYTES
                ? entry.blob.slice(0, SLICE_HEADER_BYTES, entry.type)
                : entry.blob;
            const base64Data = await blobToBase64(targetBlob);

            window.dispatchEvent(
              new CustomEvent("AEGIS_INTERCEPTED_BLOB", {
                detail: {
                  blobUrl: href,
                  filename: filename,
                  mimeType: entry.type,
                  originalSize: entry.size,
                  magicHex: magicHex,
                  base64Data: base64Data
                }
              })
            );
          } catch (e) {
            approvedBlobUrls.add(href);
            originalAnchorClick.call(anchorRef);
          }
        })();
        return;
      }
    }

    if (isGmailAttachmentUrl(href)) {
      const norm = normalizeAttachmentUrl(href);
      if (verifiedUrlBlobs.has(norm)) {
        const cached = verifiedUrlBlobs.get(norm);
        triggerDirectBlobDownload(cached.blob, downloadAttr || cached.filename);
        return;
      }
      window.dispatchEvent(
        new CustomEvent("AEGIS_INTERCEPTED_GMAIL_URL", {
          detail: {
            url: href,
            filename: downloadAttr || "gmail_attachment"
          }
        })
      );
      return;
    }

    return originalAnchorClick.apply(this, arguments);
  };

  // 3. GMAIL: Hook Hidden Download Iframes & window.open
  if (location.hostname === "mail.google.com") {
    try {
      const iframeSrcDesc = Object.getOwnPropertyDescriptor(
        HTMLIFrameElement.prototype,
        "src"
      );
      if (iframeSrcDesc && iframeSrcDesc.set) {
        Object.defineProperty(HTMLIFrameElement.prototype, "src", {
          get: function () {
            return iframeSrcDesc.get.call(this);
          },
          set: function (val) {
            const urlStr = String(val || "");
            if (isGmailAttachmentUrl(urlStr)) {
              const norm = normalizeAttachmentUrl(urlStr);
              if (verifiedUrlBlobs.has(norm)) {
                const cached = verifiedUrlBlobs.get(norm);
                triggerDirectBlobDownload(cached.blob, cached.filename);
                return;
              }
              window.dispatchEvent(
                new CustomEvent("AEGIS_INTERCEPTED_GMAIL_URL", {
                  detail: {
                    url: urlStr,
                    filename: "gmail_attachment"
                  }
                })
              );
              return;
            }
            return iframeSrcDesc.set.call(this, val);
          },
          configurable: true
        });
      }
    } catch (err) {}

    const originalWindowOpen = window.open;
    window.open = function (url) {
      const urlStr = String(url || "");
      if (isGmailAttachmentUrl(urlStr)) {
        const norm = normalizeAttachmentUrl(urlStr);
        if (verifiedUrlBlobs.has(norm)) {
          const cached = verifiedUrlBlobs.get(norm);
          triggerDirectBlobDownload(cached.blob, cached.filename);
          return null;
        }
        window.dispatchEvent(
          new CustomEvent("AEGIS_INTERCEPTED_GMAIL_URL", {
            detail: {
              url: urlStr,
              filename: "gmail_attachment"
            }
          })
        );
        return null;
      }
      return originalWindowOpen.apply(this, arguments);
    };
  }

  // 4. Receive Verified Blob / Verdict from Isolated Content Script
  window.addEventListener("AEGIS_BLOB_VERDICT", (event) => {
    const {
      blobUrl,
      gmailUrl,
      filename,
      action,
      base64Data,
      mimeType,
      triggerDownload
    } = event.detail || {};

    if (action === "ALLOW") {
      let verifiedBlob = null;
      if (base64Data) {
        try {
          const binStr = atob(base64Data);
          const bytes = new Uint8Array(binStr.length);
          for (let i = 0; i < binStr.length; i++) bytes[i] = binStr.charCodeAt(i);
          verifiedBlob = new Blob([bytes], {
            type: mimeType || "application/octet-stream"
          });
        } catch (e) {}
      }

      if (gmailUrl && verifiedBlob) {
        verifiedUrlBlobs.set(normalizeAttachmentUrl(gmailUrl), {
          blob: verifiedBlob,
          filename: filename || "verified_attachment"
        });
      }

      if (triggerDownload) {
        if (verifiedBlob) {
          triggerDirectBlobDownload(verifiedBlob, filename);
          return;
        }
        if (blobUrl) {
          approvedBlobUrls.add(blobUrl);
          const entry = blobRegistry.get(blobUrl);
          if (entry && entry.blob) {
            triggerDirectBlobDownload(entry.blob, filename);
          } else {
            const tempAnchor = document.createElement("a");
            tempAnchor.href = blobUrl;
            tempAnchor.download = filename || "verified_file";
            tempAnchor.style.display = "none";
            document.body.appendChild(tempAnchor);
            originalAnchorClick.call(tempAnchor);
            setTimeout(() => tempAnchor.remove(), 1000);
          }
        }
      }
    } else if (action === "BLOCK") {
      if (blobUrl) {
        blobRegistry.delete(blobUrl);
        try {
          URL.revokeObjectURL(blobUrl);
        } catch (e) {}
      }
    }
  });
})();
