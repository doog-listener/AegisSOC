/**
 * AegisSOC Edge Interceptor v2.6.1 - Isolated Content Script & Draggable Shadow DOM HUD (content.js)
 * Features:
 * 1. Draggable Floating Pill & Card Header (bottom: 85px default clears WhatsApp Send button)
 *    with click-vs-drag guard, viewport clamping, auto-flip, and localStorage persistence.
 * 2. Live handshake with https://aegis-soc-security.vercel.app so the console displays "Shield Active".
 * 3. Direct Download (No New Tab), Full PDF Scanning, and 0ms Cached Download Reuse.
 */
(function () {
  const CONSOLE_URL = "https://aegis-soc-security.vercel.app";
  const POS_STORAGE_KEY = "aegissoc_hud_pos_v1";

  // Notify AegisSOC Executive Console when visited so the website shows "Shield Active"
  if (location.hostname === "aegis-soc-security.vercel.app") {
    document.documentElement.dataset.aegissocInstalled = "2.6.1";
    window.dispatchEvent(
      new CustomEvent("AEGISSOC_EXTENSION_READY", {
        detail: { version: "2.6.1" }
      })
    );
    return;
  }

  const sessionAttachmentCache = new Map();
  let lastPreviewedAttachment = null;

  function normalizeAttachmentKey(rawUrl, filename = "") {
    try {
      const u = new URL(rawUrl, location.origin);
      const attid = u.searchParams.get("attid") || "";
      const permmsgid =
        u.searchParams.get("permmsgid") || u.searchParams.get("th") || "";
      const realattid = u.searchParams.get("realattid") || "";
      if (permmsgid || attid || realattid) {
        return `gmail:${permmsgid}:${attid}:${realattid}:${filename.toLowerCase()}`;
      }
      u.searchParams.delete("disp");
      u.searchParams.delete("zw");
      u.searchParams.delete("s");
      return `url:${u.toString()}`;
    } catch (e) {
      return `raw:${rawUrl}:${filename}`;
    }
  }

  // 1. Build Closed Shadow DOM HUD (bottom: 85px clears WhatsApp Web Send button)
  const hostEl = document.createElement("div");
  hostEl.id = "aegissoc-shadow-host";
  hostEl.style.cssText =
    "all: initial; position: fixed; z-index: 2147483647; bottom: 85px; right: 24px; font-family: Inter, system-ui, sans-serif; touch-action: none;";
  document.documentElement.appendChild(hostEl);

  const shadow = hostEl.attachShadow({ mode: "closed" });

  shadow.innerHTML = `
    <style>
      * { box-sizing: border-box; font-family: 'Inter', -apple-system, BlinkMacSystemFont, monospace, sans-serif; }
      .aegis-wrapper {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 10px;
      }
      .aegis-wrapper.flip-down {
        flex-direction: column-reverse;
      }
      .aegis-wrapper.align-left {
        align-items: flex-start;
      }
      .aegis-pill {
        display: flex; align-items: center; gap: 8px;
        background: rgba(6, 11, 24, 0.94); color: #f1f5f9;
        border: 1px solid rgba(56, 189, 248, 0.45);
        padding: 8px 14px; border-radius: 999px;
        font-size: 12px; font-weight: 600;
        cursor: grab; user-select: none;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.65), 0 0 15px rgba(56, 189, 248, 0.2);
        backdrop-filter: blur(12px); transition: border-color 0.2s ease, box-shadow 0.2s ease;
      }
      .aegis-pill:hover { border-color: #38bdf8; }
      .aegis-pill.dragging { cursor: grabbing; box-shadow: 0 12px 32px rgba(0, 0, 0, 0.85), 0 0 22px rgba(56, 189, 248, 0.45); }
      .drag-grip {
        color: #64748b; font-size: 12px; letter-spacing: -1px; margin-right: 2px;
      }
      .pulse-dot {
        width: 8px; height: 8px; border-radius: 50%;
        background: #10b981; box-shadow: 0 0 8px #10b981;
      }
      .aegis-card {
        display: none; width: 375px;
        background: rgba(10, 16, 31, 0.97); color: #f1f5f9;
        border: 1px solid rgba(56, 189, 248, 0.4);
        border-radius: 16px; padding: 16px;
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.85), 0 0 25px rgba(56, 189, 248, 0.15);
        backdrop-filter: blur(16px);
      }
      .aegis-card.active { display: block; }
      .aegis-card.threat { border-color: rgba(244, 63, 94, 0.85); box-shadow: 0 20px 50px rgba(0,0,0,0.9), 0 0 30px rgba(244, 63, 94, 0.35); }
      .aegis-card.clean { border-color: rgba(16, 185, 129, 0.75); }
      .card-header {
        display: flex; justify-content: space-between; align-items: center;
        border-bottom: 1px solid rgba(51, 65, 85, 0.6); padding-bottom: 10px; margin-bottom: 12px;
        cursor: grab; user-select: none;
      }
      .card-header:active { cursor: grabbing; }
      .card-title { font-size: 13px; font-weight: 700; color: #ffffff; display: flex; align-items: center; gap: 6px; }
      .close-btn { background: none; border: none; color: #94a3b8; cursor: pointer; font-size: 15px; font-weight: bold; }
      .close-btn:hover { color: #ffffff; }
      .meta-row { font-size: 11px; color: #94a3b8; margin-bottom: 6px; word-break: break-all; font-family: monospace; }
      .verdict-banner {
        padding: 10px 12px; border-radius: 10px; font-size: 12px; font-weight: 700;
        margin: 10px 0; display: flex; justify-content: space-between; align-items: center;
      }
      .verdict-scanning { background: rgba(56, 189, 248, 0.12); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); }
      .verdict-threat { background: rgba(244, 63, 94, 0.18); color: #fb7185; border: 1px solid rgba(244, 63, 94, 0.45); }
      .verdict-clean { background: rgba(16, 185, 129, 0.16); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.4); }
      .summary-box { font-size: 11.5px; line-height: 1.45; color: #cbd5e1; background: rgba(2, 6, 23, 0.65); padding: 10px; border-radius: 8px; border: 1px solid rgba(30, 41, 59, 0.8); margin-bottom: 10px; }
      .btn-row { display: flex; gap: 8px; margin-top: 10px; }
      .btn {
        flex: 1; padding: 8px 10px; border-radius: 8px; font-size: 11px; font-weight: 600;
        text-align: center; cursor: pointer; border: none; text-decoration: none;
        transition: opacity 0.2s;
      }
      .btn:hover { opacity: 0.9; }
      .btn-primary { background: #38bdf8; color: #030712; }
      .drop-test-zone {
        margin-top: 8px; padding: 10px; border: 1px dashed rgba(56, 189, 248, 0.4);
        border-radius: 8px; text-align: center; font-size: 11px; color: #94a3b8; cursor: pointer;
      }
      .drop-test-zone:hover { border-color: #38bdf8; color: #e2e8f0; background: rgba(56, 189, 248, 0.05); }
    </style>

    <div class="aegis-wrapper" id="aegisWrapper">
      <div class="aegis-card" id="aegisCard">
        <div class="card-header" id="cardDragHandle" title="Drag to reposition">
          <div class="card-title">AegisSOC Edge Interceptor v2.6.1</div>
          <button class="close-btn" id="closeCardBtn">X</button>
        </div>
        <div class="meta-row" id="fileMetaRow">Monitoring WhatsApp Web & Gmail attachments...</div>
        <div class="verdict-banner verdict-scanning" id="verdictBanner">
          <span id="verdictText">STANDBY // ZERO-TRUST GATE</span>
          <span id="confidenceText">PE | PDF | Media</span>
        </div>
        <div class="summary-box" id="summaryBox">
          Binaries (.exe/.dll), PDFs (.pdf), and Raster Media (.png/.jpg) are inspected once and cached for instant, direct downloads.
        </div>
        <input type="file" id="manualFileInput" style="display:none" />
        <div class="drop-test-zone" id="manualScanTrigger">
          Click Here to Test Manual File Triage
        </div>
        <div class="btn-row">
          <a class="btn btn-primary" href="${CONSOLE_URL}" target="_blank" rel="noopener noreferrer">Open Executive Console</a>
        </div>
      </div>

      <div class="aegis-pill" id="aegisPill" title="Drag to move - Click to toggle console">
        <span class="drag-grip">::</span>
        <span class="pulse-dot" id="pillDot"></span>
        <span id="pillLabel">AegisSOC Shield Active</span>
      </div>
    </div>
  `;

  const wrapperEl = shadow.getElementById("aegisWrapper");
  const cardEl = shadow.getElementById("aegisCard");
  const cardDragHandle = shadow.getElementById("cardDragHandle");
  const pillEl = shadow.getElementById("aegisPill");
  const pillDot = shadow.getElementById("pillDot");
  const pillLabel = shadow.getElementById("pillLabel");
  const closeCardBtn = shadow.getElementById("closeCardBtn");
  const fileMetaRow = shadow.getElementById("fileMetaRow");
  const verdictBanner = shadow.getElementById("verdictBanner");
  const verdictText = shadow.getElementById("verdictText");
  const confidenceText = shadow.getElementById("confidenceText");
  const summaryBox = shadow.getElementById("summaryBox");
  const manualScanTrigger = shadow.getElementById("manualScanTrigger");
  const manualFileInput = shadow.getElementById("manualFileInput");

  // DRAGGABLE HUD CONTROLLER
  let isPointerDown = false;
  let hasMovedBeyondThreshold = false;
  let suppressNextClick = false;
  let dragOffsetX = 0;
  let dragOffsetY = 0;
  let startClientX = 0;
  let startClientY = 0;

  function updateCardOrientation(leftPx, topPx) {
    if (topPx < window.innerHeight * 0.45) {
      wrapperEl.classList.add("flip-down");
    } else {
      wrapperEl.classList.remove("flip-down");
    }
    if (leftPx < window.innerWidth * 0.5) {
      wrapperEl.classList.add("align-left");
    } else {
      wrapperEl.classList.remove("align-left");
    }
  }

  function applyClampedPosition(leftPx, topPx) {
    const rect = hostEl.getBoundingClientRect();
    const maxLeft = Math.max(8, window.innerWidth - rect.width - 8);
    const maxTop = Math.max(8, window.innerHeight - rect.height - 8);
    const clampedLeft = Math.min(Math.max(8, leftPx), maxLeft);
    const clampedTop = Math.min(Math.max(8, topPx), maxTop);

    hostEl.style.left = `${clampedLeft}px`;
    hostEl.style.top = `${clampedTop}px`;
    hostEl.style.right = "auto";
    hostEl.style.bottom = "auto";

    updateCardOrientation(clampedLeft, clampedTop);
    return { left: clampedLeft, top: clampedTop };
  }

  try {
    const saved = JSON.parse(localStorage.getItem(POS_STORAGE_KEY) || "null");
    if (saved && typeof saved.left === "number" && typeof saved.top === "number") {
      requestAnimationFrame(() => applyClampedPosition(saved.left, saved.top));
    }
  } catch (e) {}

  function startDrag(e) {
    if (e.button !== 0 || e.target === closeCardBtn) return;
    isPointerDown = true;
    hasMovedBeyondThreshold = false;
    startClientX = e.clientX;
    startClientY = e.clientY;

    const rect = hostEl.getBoundingClientRect();
    dragOffsetX = e.clientX - rect.left;
    dragOffsetY = e.clientY - rect.top;
  }

  pillEl.addEventListener("mousedown", startDrag);
  cardDragHandle.addEventListener("mousedown", startDrag);

  window.addEventListener(
    "mousemove",
    (e) => {
      if (!isPointerDown) return;
      const dist = Math.hypot(e.clientX - startClientX, e.clientY - startClientY);
      if (dist > 5) {
        hasMovedBeyondThreshold = true;
        pillEl.classList.add("dragging");
        applyClampedPosition(e.clientX - dragOffsetX, e.clientY - dragOffsetY);
      }
    },
    true
  );

  window.addEventListener(
    "mouseup",
    () => {
      if (!isPointerDown) return;
      isPointerDown = false;
      pillEl.classList.remove("dragging");

      if (hasMovedBeyondThreshold) {
        suppressNextClick = true;
        const rect = hostEl.getBoundingClientRect();
        try {
          localStorage.setItem(
            POS_STORAGE_KEY,
            JSON.stringify({ left: rect.left, top: rect.top })
          );
        } catch (e) {}
        setTimeout(() => {
          suppressNextClick = false;
        }, 120);
      }
    },
    true
  );

  window.addEventListener("resize", () => {
    if (hostEl.style.left && hostEl.style.left !== "auto") {
      const rect = hostEl.getBoundingClientRect();
      applyClampedPosition(rect.left, rect.top);
    }
  });

  pillEl.addEventListener("click", (e) => {
    if (suppressNextClick || hasMovedBeyondThreshold) {
      e.stopPropagation();
      return;
    }
    cardEl.classList.toggle("active");
    if (hostEl.style.left && hostEl.style.left !== "auto") {
      const rect = hostEl.getBoundingClientRect();
      applyClampedPosition(rect.left, rect.top);
    }
  });

  closeCardBtn.addEventListener("click", () => cardEl.classList.remove("active"));
  manualScanTrigger.addEventListener("click", () => manualFileInput.click());

  manualFileInput.addEventListener("change", (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      const res = String(reader.result || "");
      const base64Data = res.includes(",") ? res.split(",")[1] : res;
      processInterceptedPayload({
        blobUrl: null,
        filename: file.name,
        mimeType: file.type || "application/octet-stream",
        originalSize: file.size,
        magicHex: "MANUAL_INSPECTION",
        base64Data: base64Data
      });
    };
    reader.readAsDataURL(file);
  });

  function showScanningUI(filename, sizeBytes, magicHex, actionLabel = "Hold Gate") {
    cardEl.className = "aegis-card active";
    pillDot.style.background = "#38bdf8";
    pillLabel.textContent = `Scanning: ${filename}`;
    const kb = sizeBytes ? (sizeBytes / 1024).toFixed(1) + " KB" : "Attachment Stream";
    fileMetaRow.textContent = `Target: ${filename} (${kb}) | Source: [${magicHex || "AUTO"}]`;
    verdictBanner.className = "verdict-banner verdict-scanning";
    verdictText.textContent = "NEURAL & STRUCTURAL TRIAGE...";
    confidenceText.textContent = actionLabel;
    summaryBox.textContent =
      "Inspecting PE binary matrix, PDF active triggers (/JavaScript, /OpenAction, /Launch, /EmbeddedFile), and steganography entropy...";
  }

  function isThreatVerdict(data) {
    const risk = String(data.risk_level || "LOW").toUpperCase();
    const verdict = String(data.verdict || "BENIGN").toUpperCase();
    return (
      risk === "CRITICAL" ||
      risk === "HIGH" ||
      verdict.includes("MALICIOUS") ||
      verdict.includes("SUSPICIOUS")
    );
  }

  function renderVerdictUI(filename, data, options = {}) {
    const {
      blobUrl,
      gmailUrl,
      base64Data,
      mimeType,
      triggerDownload = true,
      actionContext = "Download",
      fromCache = false
    } = options;

    const verdict = String(data.verdict || "BENIGN").toUpperCase();
    const isThreat = isThreatVerdict(data);
    const conf =
      data.confidence !== null && data.confidence !== undefined
        ? Math.round(data.confidence)
        : isThreat
        ? 98
        : 5;
    const ai = data.ai_analysis || {};

    if (isThreat) {
      cardEl.className = "aegis-card active threat";
      pillDot.style.background = "#f43f5e";
      pillDot.style.boxShadow = "0 0 10px #f43f5e";
      pillLabel.textContent = `Threat Blocked: ${filename}`;
      verdictBanner.className = "verdict-banner verdict-threat";
      verdictText.textContent = `BLOCKED: ${verdict}`;
      confidenceText.textContent = `${conf}% Risk`;
      summaryBox.textContent = `${
        ai.executive_summary || "Malicious payload or active exploit trigger detected."
      } Action: ${actionContext} blocked & quarantined.`;

      if (blobUrl || gmailUrl) {
        window.dispatchEvent(
          new CustomEvent("AEGIS_BLOB_VERDICT", {
            detail: { blobUrl, gmailUrl, filename, action: "BLOCK" }
          })
        );
      }
    } else {
      cardEl.className = "aegis-card active clean";
      pillDot.style.background = "#10b981";
      pillDot.style.boxShadow = "0 0 8px #10b981";
      pillLabel.textContent = `Verified Clean: ${filename}`;
      verdictBanner.className = "verdict-banner verdict-clean";
      verdictText.textContent = fromCache
        ? "CACHED VERIFIED CLEAN"
        : `CLEAN: ${verdict}`;
      confidenceText.textContent = fromCache ? "0ms Reuse" : `${conf}% Risk`;
      summaryBox.textContent = fromCache
        ? `Already verified clean during preview. Releasing "${filename}" directly to your Downloads folder without re-scanning.`
        : `${
            ai.executive_summary ||
            "Inspection passed with clean structural and neural signatures."
          } Action: ${actionContext} released directly.`;

      window.dispatchEvent(
        new CustomEvent("AEGIS_BLOB_VERDICT", {
          detail: {
            blobUrl,
            gmailUrl,
            filename,
            base64Data,
            mimeType,
            triggerDownload: !!triggerDownload,
            action: "ALLOW"
          }
        })
      );
    }
    return !isThreat;
  }

  function processInterceptedPayload(payload) {
    const { blobUrl, filename, mimeType, originalSize, magicHex, base64Data } =
      payload;
    showScanningUI(filename, originalSize, magicHex);

    chrome.runtime.sendMessage(
      {
        type: "AEGIS_ANALYZE_FILE",
        filename,
        mimeType,
        base64Data
      },
      (response) => {
        if (chrome.runtime.lastError || !response || response.error) {
          const errMsg =
            (response && response.error) ||
            (chrome.runtime.lastError && chrome.runtime.lastError.message) ||
            "Backend unreachable";
          verdictBanner.className = "verdict-banner verdict-threat";
          verdictText.textContent = "TRIAGE ERROR";
          confidenceText.textContent = "Held";
          summaryBox.textContent = `Could not verify file safety (${errMsg}). Check Executive Console.`;
          return;
        }
        renderVerdictUI(filename, response.data, {
          blobUrl,
          base64Data,
          mimeType,
          triggerDownload: true
        });
      }
    );
  }

  window.addEventListener("AEGIS_INTERCEPTED_BLOB", (event) => {
    if (event.detail) {
      processInterceptedPayload(event.detail);
    }
  });

  window.addEventListener("AEGIS_INTERCEPTED_GMAIL_URL", (event) => {
    const { url, filename } = event.detail || {};
    if (!url) return;

    const key = normalizeAttachmentKey(url, filename);
    const cached =
      sessionAttachmentCache.get(key) ||
      (lastPreviewedAttachment &&
      (url.includes("googleusercontent.com") || url.includes("view=att"))
        ? lastPreviewedAttachment
        : null);

    if (cached) {
      renderVerdictUI(cached.filename || filename, cached.verdictData, {
        gmailUrl: url,
        base64Data: cached.base64Data,
        mimeType: cached.mimeType,
        triggerDownload: cached.isClean,
        actionContext: "Download",
        fromCache: true
      });
      return;
    }

    scanGmailUrlAndAct(url, filename || "gmail_attachment", {
      triggerDownload: true,
      actionContext: "Download"
    });
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "AEGIS_BG_SCAN_START") {
      showScanningUI(message.filename, message.sizeBytes || 0, "BROWSER_DOWNLOAD_GATE");
    } else if (message.type === "AEGIS_BG_SCAN_RESULT") {
      renderVerdictUI(message.filename, message.data, {
        base64Data: message.base64Data,
        mimeType: message.mimeType,
        triggerDownload: !isThreatVerdict(message.data),
        actionContext: "Download"
      });
    } else if (message.type === "AEGIS_BG_SCAN_ERROR") {
      cardEl.className = "aegis-card active threat";
      verdictBanner.className = "verdict-banner verdict-threat";
      verdictText.textContent = "UNVERIFIED DOWNLOAD HELD";
      summaryBox.textContent = `Download aborted because scan failed: ${message.error}`;
    }
  });

  function parseGmailDownloadUrlAttr(raw) {
    if (!raw) return null;
    const httpIdx = raw.indexOf(":http");
    if (httpIdx === -1) return null;
    const url = raw.substring(httpIdx + 1);
    const prefix = raw.substring(0, httpIdx);
    const firstColon = prefix.indexOf(":");
    if (firstColon === -1) {
      return {
        mimeType: "application/octet-stream",
        filename: prefix || "gmail_attachment",
        url
      };
    }
    return {
      mimeType: prefix.substring(0, firstColon) || "application/octet-stream",
      filename: prefix.substring(firstColon + 1) || "gmail_attachment",
      url
    };
  }

  function paintGmailCardBadge(cardNode, state, labelText) {
    let badge = cardNode.querySelector(".aegis-inline-badge");
    if (!badge) {
      badge = document.createElement("div");
      badge.className = "aegis-inline-badge";
      badge.style.cssText =
        "position:absolute; top:4px; left:4px; z-index:999; padding:2px 7px; border-radius:6px; font-size:10px; font-weight:700; font-family:monospace; pointer-events:none; box-shadow:0 2px 8px rgba(0,0,0,0.4);";
      if (getComputedStyle(cardNode).position === "static") {
        cardNode.style.position = "relative";
      }
      cardNode.appendChild(badge);
    }
    if (state === "SCANNING") {
      badge.style.background = "rgba(3, 7, 18, 0.92)";
      badge.style.color = "#38bdf8";
      badge.style.border = "1px solid #38bdf8";
      badge.textContent = labelText || "Scanning...";
    } else if (state === "BLOCK") {
      badge.style.background = "rgba(136, 19, 55, 0.96)";
      badge.style.color = "#fda4af";
      badge.style.border = "1px solid #f43f5e";
      badge.textContent = labelText || "QUARANTINED";
      cardNode.style.outline = "2px solid #f43f5e";
      cardNode.style.filter = "grayscale(60%)";
    } else if (state === "ALLOW") {
      badge.style.background = "rgba(6, 78, 59, 0.95)";
      badge.style.color = "#6ee7b7";
      badge.style.border = "1px solid #10b981";
      badge.textContent = labelText || "VERIFIED CLEAN";
      cardNode.style.outline = "2px solid #10b981";
    } else {
      badge.style.background = "rgba(15, 23, 42, 0.88)";
      badge.style.color = "#38bdf8";
      badge.style.border = "1px solid rgba(56, 189, 248, 0.45)";
      badge.textContent = labelText || "AegisSOC Gate";
    }
  }

  function scanGmailUrlAndAct(url, filename, opts = {}) {
    const { cardNode, clickedTarget, isDownloadButton, triggerDownload } = opts;
    const cacheKey = normalizeAttachmentKey(url, filename);

    if (sessionAttachmentCache.has(cacheKey)) {
      const cached = sessionAttachmentCache.get(cacheKey);
      renderVerdictUI(cached.filename || filename, cached.verdictData, {
        gmailUrl: url,
        base64Data: cached.base64Data,
        mimeType: cached.mimeType,
        triggerDownload: !!(cached.isClean && (isDownloadButton || triggerDownload)),
        actionContext: isDownloadButton || triggerDownload ? "Download" : "Preview & Open",
        fromCache: true
      });
      if (cached.isClean && !isDownloadButton && clickedTarget) {
        lastPreviewedAttachment = cached;
        setTimeout(() => {
          clickedTarget.dispatchEvent(
            new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window })
          );
          clickedTarget.dispatchEvent(
            new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window })
          );
          clickedTarget.dispatchEvent(
            new MouseEvent("click", { bubbles: true, cancelable: true, view: window })
          );
        }, 40);
      }
      return;
    }

    const actionLabel = isDownloadButton || triggerDownload ? "Download Gate" : "Preview Gate";
    showScanningUI(filename, 0, "GMAIL_ATTACHMENT", actionLabel);

    if (cardNode) {
      cardNode.dataset.aegisVerdict = "SCANNING";
      paintGmailCardBadge(cardNode, "SCANNING", "Scanning...");
    }

    chrome.runtime.sendMessage(
      {
        type: "AEGIS_ANALYZE_URL",
        url: url,
        filename: filename
      },
      (response) => {
        if (chrome.runtime.lastError || !response || response.error) {
          const errMsg =
            (response && response.error) ||
            (chrome.runtime.lastError && chrome.runtime.lastError.message) ||
            "Scan failed";
          if (cardNode) {
            delete cardNode.dataset.aegisVerdict;
            paintGmailCardBadge(cardNode, "BLOCK", "Scan Error");
          }
          verdictBanner.className = "verdict-banner verdict-threat";
          verdictText.textContent = "SCAN ERROR";
          confidenceText.textContent = "Blocked";
          summaryBox.textContent = `Attachment held because verification failed: ${errMsg}`;
          return;
        }

        const finalName = response.resolvedFilename || filename;
        const isClean = renderVerdictUI(finalName, response.data, {
          gmailUrl: url,
          base64Data: response.base64Data,
          mimeType: response.mimeType,
          triggerDownload: !!(isDownloadButton || triggerDownload),
          actionContext: isDownloadButton || triggerDownload ? "Download" : "Preview & Open"
        });

        const cacheEntry = {
          isClean,
          verdictData: response.data,
          base64Data: response.base64Data,
          mimeType: response.mimeType,
          filename: finalName,
          gmailUrl: url
        };
        sessionAttachmentCache.set(cacheKey, cacheEntry);
        if (isClean && !isDownloadButton) {
          lastPreviewedAttachment = cacheEntry;
        }

        if (cardNode) {
          if (isClean) {
            cardNode.dataset.aegisVerdict = "ALLOW";
            paintGmailCardBadge(cardNode, "ALLOW", "VERIFIED CLEAN");
            if (!isDownloadButton && clickedTarget) {
              setTimeout(() => {
                clickedTarget.dispatchEvent(
                  new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window })
                );
                clickedTarget.dispatchEvent(
                  new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window })
                );
                clickedTarget.dispatchEvent(
                  new MouseEvent("click", { bubbles: true, cancelable: true, view: window })
                );
              }, 80);
            }
          } else {
            cardNode.dataset.aegisVerdict = "BLOCK";
            paintGmailCardBadge(cardNode, "BLOCK", "MALICIOUS // BLOCKED");
          }
        }
      }
    );
  }

  if (location.hostname === "mail.google.com") {
    const observer = new MutationObserver(() => {
      document.querySelectorAll("[download_url]").forEach((card) => {
        if (!card.dataset.aegisHooked) {
          card.dataset.aegisHooked = "1";
          const parsed = parseGmailDownloadUrlAttr(card.getAttribute("download_url"));
          if (parsed && parsed.url) {
            const key = normalizeAttachmentKey(parsed.url, parsed.filename);
            if (sessionAttachmentCache.has(key)) {
              const cached = sessionAttachmentCache.get(key);
              card.dataset.aegisVerdict = cached.isClean ? "ALLOW" : "BLOCK";
              paintGmailCardBadge(
                card,
                cached.isClean ? "ALLOW" : "BLOCK",
                cached.isClean ? "VERIFIED CLEAN" : "MALICIOUS // BLOCKED"
              );
              return;
            }
          }
          paintGmailCardBadge(card, "STANDBY", "AegisSOC Gate");
        }
      });
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });

    const interceptGmailEvent = (e) => {
      if (!e.isTrusted) return;

      const dialogNode = e.target.closest("div[role='dialog']");
      if (dialogNode && lastPreviewedAttachment) {
        const dlBtn = e.target.closest(
          "[data-tooltip*='Download'], [aria-label*='Download'], [data-tooltip*='download'], [aria-label*='download']"
        );
        if (dlBtn) {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();

          if (e.type === "click" || e.type === "mousedown") {
            renderVerdictUI(
              lastPreviewedAttachment.filename,
              lastPreviewedAttachment.verdictData,
              {
                gmailUrl: lastPreviewedAttachment.gmailUrl,
                base64Data: lastPreviewedAttachment.base64Data,
                mimeType: lastPreviewedAttachment.mimeType,
                triggerDownload: lastPreviewedAttachment.isClean,
                actionContext: "Download",
                fromCache: true
              }
            );
          }
          return;
        }
      }

      const cardNode = e.target.closest("[download_url]");
      if (cardNode) {
        const verdictState = cardNode.dataset.aegisVerdict;
        const parsed = parseGmailDownloadUrlAttr(cardNode.getAttribute("download_url"));
        const isDownloadButton = !!e.target.closest(
          "[data-tooltip*='Download'], [aria-label*='Download'], [data-tooltip*='download'], [aria-label*='download'], .aSK, .aQv, a[download]"
        );

        if (verdictState === "ALLOW") {
          if (isDownloadButton && parsed && parsed.url) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            if (e.type === "click" || e.type === "mousedown") {
              scanGmailUrlAndAct(parsed.url, parsed.filename, {
                cardNode,
                clickedTarget: e.target,
                isDownloadButton: true
              });
            }
          }
          if (!isDownloadButton && parsed && parsed.url) {
            const key = normalizeAttachmentKey(parsed.url, parsed.filename);
            if (sessionAttachmentCache.has(key)) {
              lastPreviewedAttachment = sessionAttachmentCache.get(key);
            }
          }
          return;
        }

        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        if (verdictState === "BLOCK") {
          if (e.type === "click" || e.type === "mousedown") {
            cardEl.className = "aegis-card active threat";
            verdictBanner.className = "verdict-banner verdict-threat";
            verdictText.textContent = "QUARANTINED ATTACHMENT";
            summaryBox.textContent =
              "This attachment failed AegisSOC inspection. Opening and downloading are permanently blocked.";
          }
          return;
        }

        if (verdictState === "SCANNING") {
          return;
        }

        if ((e.type === "mousedown" || e.type === "click") && parsed && parsed.url) {
          scanGmailUrlAndAct(parsed.url, parsed.filename, {
            cardNode,
            clickedTarget: e.target,
            isDownloadButton
          });
        }
        return;
      }

      const inlineImg = e.target.closest(".a3s img");
      if (inlineImg && inlineImg.src && (inlineImg.naturalWidth > 64 || inlineImg.width > 64)) {
        const imgState = inlineImg.dataset.aegisVerdict;
        if (imgState === "ALLOW") return;

        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        if (imgState === "BLOCK" || imgState === "SCANNING") return;

        if (e.type === "mousedown" || e.type === "click") {
          inlineImg.dataset.aegisVerdict = "SCANNING";
          const imgName = inlineImg.getAttribute("alt") || "inline_email_image.png";
          scanGmailUrlAndAct(inlineImg.src, imgName, {
            cardNode: inlineImg.parentElement || inlineImg,
            clickedTarget: inlineImg,
            isDownloadButton: false
          });
        }
      }
    };

    window.addEventListener("mousedown", interceptGmailEvent, true);
    window.addEventListener("mouseup", interceptGmailEvent, true);
    window.addEventListener("click", interceptGmailEvent, true);
  }
})();
